# ShopFlow

A real e-commerce app connected to Supabase (auth, cart, orders, admin dashboard).

## Deploy without a computer (phone-friendly)

1. Go to github.com on your phone browser, log in (or sign up).
2. Create a new repository (e.g. "shopflow").
3. Use "Add file → Upload files" and upload every file/folder from this project
   (keep the `src` folder structure intact).
4. Go to vercel.com, log in with your GitHub account.
5. Click "Add New Project", pick your `shopflow` repo, click Deploy.
6. Wait ~1 minute — you'll get a live URL. Signup/login will work there
   because it's a real website, not a sandboxed preview.

## Deploy with a computer instead

```
npm install
npm run dev
```
